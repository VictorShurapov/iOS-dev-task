/*: (c) Ivan Misuno 2024, FabFun.ai, Kukumber.kids
 # iOS Dev Playground
 
 When learning multiplication tables, kids are first given introductory tasks like this one:
 ```
 There are 5 groups, each group has 6 items.
 How many items are there in total?
 +------+  +------+  +------+   <---- 5 groups
 | *  * |  | *  * |  | *  * |
 | *  * |  | *  * |  | *  *<--------- Each group has 6 items
 | *  * |  | *  * |  | *  * |
 +------+  +------+  +------+
 +------+  +------+
 | *  * |  | *  * |
 | *  * |  | *  * |
 | *  * |  | *  * |
 +------+  +------+
 ```
 **🔗 [UI Mockup](https://drive.google.com/file/d/12nZTUiVtHJEVe-T9C7_po6T03K3zoXMW/)**
 
 The goal for the kid is to count items in one group (6), and do 5 additions:
 6 + 6 + 6 + 6 + 6 = 30
 
 Our goal, as developers, is to implement such screen (UI + underlying algorithms).
 
 - Callout(Task #1): Generate Random Multipliers. We want the app to present a series of such screens, with random number of groups and items `(numGroups, numItems)`, such that `numGroups * numItems <= N`, `N = const` (e.g., 30), eg:
 - (3 groups, 4 items)
 - (4 groups, 5 items)
 - (5 groups, 6 items)
 - (6 groups, 3 items)
 - ...
 */
import SwiftUI
import PlaygroundSupport

/*
 func generateRandomMultipliers(maxObjectCount: Int) -> (numGroups: Int, numItems: Int) {
   return (numGroups: 5, numItems: 6)
 }
 */

func generateRandomMultipliers(maxObjectCount: Int = 30) -> (numGroups: Int, numItems: Int) {
    // Ensure maxObjectCount is at least 4 to have valid pairs (numGroups, numItems) >= 2
    guard maxObjectCount >= 4 else { return (0,0) }
    
    var validPairs = [(Int, Int)]()
    
    // Generate all possible pairs (numGroups, numItems) such that numGroups * numItems <= maxObjectCount
    // and both numGroups and numItems are at least 2
    for numGroups in 2...maxObjectCount {
        for numItems in 2...maxObjectCount {
            if numGroups * numItems <= maxObjectCount {
                validPairs.append((numGroups, numItems))
            } else {
                // Skip further iterations when the product exceeds maxObjectCount
                break
            }
        }
    }
    // Return a random pair from the valid pairs, or (0, 0) if none found
    return validPairs.randomElement() ?? (0, 0)
    //return (2, 15)
}
/*:
 - Callout(Task #2): Modify `OuterGridView` so that it renders the outer and the inner grids:
 */
struct OuterGridView: View {
    enum Const {
        static let cornerRadius: CGFloat = 12
        static let itemSize: CGFloat = 100
        static let itemSpacing: CGFloat = 12
    }
    
    let numGroups: Int
    let numItemsInGroup: Int
    var numColumns: Int {
        numGroups >= 3 ? 3 : 2
    }
    
    var columns: [GridItem] {
        Array(repeating: GridItem(.flexible()), count: numColumns)
    }
    
    var body: some View {
        LazyVGrid(columns: columns, spacing: Const.itemSpacing) {
            ForEach(0..<numGroups, id: \.self) { group in
                RoundedRectangle(cornerRadius: Const.cornerRadius)
                    .fill(Color.random)
                    .frame(width: Const.itemSize, height: Const.itemSize)
                    .overlay {
                        InnerGridView(numItemsInGroup: numItemsInGroup)
                    }
            }
        }
        .padding(20)
    }
}

struct InnerGridView: View {
    enum Const {
        static let cornerRadius: CGFloat = 12
        static let itemSize: CGFloat = 20
    }
    
    let numItemsInGroup: Int
    var numColumns: Int {
        numItemsInGroup >= 3 ? 3 : 2
    }
    
    var columns: [GridItem] {
        Array(repeating: GridItem(.flexible()), count: numColumns)
    }
    
    var body: some View {
        LazyVGrid(columns: columns) {
            ForEach(0..<numItemsInGroup, id: \.self) { item in
                RoundedRectangle(cornerRadius: Const.cornerRadius)
                    .fill(Color.green)
                   // .frame(idealWidth: 10, idealHeight: 10)
                    .frame(width: Const.itemSize, height: Const.itemSize)
            }
        }
        .padding()
    }
}

// Get a pair of values to display the grid
let (numGroups, numItemsInGroup) = generateRandomMultipliers()

let taskView = OuterGridView(numGroups: numGroups, numItemsInGroup: numItemsInGroup)
PlaygroundPage.current.setLiveView(taskView)

// Test cases
func testCase(maxObjectCount: Int) -> String {
    let (numGroups, numItems) = generateRandomMultipliers(maxObjectCount: maxObjectCount)
    guard numGroups * numItems <= maxObjectCount else { return "❌ Expected numGroups * numItems <= maxObjectCount; got \(numGroups) * \(numItems) = \(numGroups * numItems)" }
    guard numGroups >= 2 else { return "❌ Expected numGroups >= 2, got \(numGroups)" }
    guard numItems >= 2 else { return "❌ Expected numItems >= 2, got \(numItems)" }
    return "✅"
}

// Test
let MAX_OBJECT_COUNT = 30
let testCases = (0..<20).map { _ in
    testCase(maxObjectCount: MAX_OBJECT_COUNT)
}
testCases.all { $0 == "✅" } ? "✅ ALL TESTS PASS" : "❌ TESTS FAIL"
